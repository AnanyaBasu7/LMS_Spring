package com.cg.lms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;

@Repository
public class LMSDaoImpl implements ILMSDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int addBook(BookDetails book) {
		entityManager.persist(book);

		int id = getMaxId();
		return id;
	}

	@Override
	public int getMaxId() {

		String query = "select max(b.id) from BookDetails b";
		Query result = entityManager.createQuery(query);
		int id = (Integer) result.getSingleResult();

		return id;
	}

	@Override
	public List<BookDetails> getAllBooks() {

		String query = "select b from BookDetails b";
		Query result = entityManager.createQuery(query);
		return result.getResultList();
	}

	@Override
	public BookDetails getBookDataBydId(int id) throws LMSException {

		System.out.println("DAO : " + id);
		BookDetails details = null;

		details = entityManager.find(BookDetails.class, id);

		if (details == null) {
			throw new LMSException("no book present with the given id:");
		}
		return details;
	}

}
