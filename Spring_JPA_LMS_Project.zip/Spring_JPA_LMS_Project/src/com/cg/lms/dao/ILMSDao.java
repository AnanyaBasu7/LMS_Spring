package com.cg.lms.dao;

import java.util.List;

import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;

public interface ILMSDao {

	int addBook(BookDetails book);

	public int getMaxId();

	List<BookDetails> getAllBooks();

	BookDetails getBookDataBydId(int id)throws LMSException;

}
