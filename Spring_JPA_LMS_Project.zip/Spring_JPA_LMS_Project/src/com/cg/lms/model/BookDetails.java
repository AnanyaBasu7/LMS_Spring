package com.cg.lms.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Book_Details_master")
public class BookDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@NotEmpty(message = "should not empty")
	private String name;
	@NotEmpty(message = "should not empty")
	private String genre;
	@NotEmpty(message = "should not empty")
	private String author;
	// @NotEmpty(message="should not empty")
	private Double cost;

	public BookDetails() {
		// TODO Auto-generated constructor stub
	}

	public BookDetails(int id, String name, String genre, String author, Double cost) {
		super();
		this.id = id;
		this.name = name;
		this.genre = genre;
		this.author = author;
		this.cost = cost;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "BookDetails [id=" + id + ", name=" + name + ", genre=" + genre + ", author=" + author + ", cost=" + cost
				+ "]";
	}

}
