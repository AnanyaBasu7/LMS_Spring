package com.cg.lms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;
import com.cg.lms.service.ILMSService;

@Controller
public class LMSController {

	@Autowired
	ILMSService service;

	@RequestMapping("/home")
	public String showHomePage() {
		String view = "home";
		return view;
	}

	@RequestMapping("/addBook")
	public String showBookDetailspage(Model model, HttpServletRequest request) {

		String view = "bookDetails";

		List<String> list = new ArrayList<>();
		list.add("fiction");
		list.add("comedy");
		list.add("horror");
		list.add("technical");

		ServletContext context = request.getServletContext();
		model.addAttribute("book", new BookDetails());
		context.setAttribute("genres", list);

		return view;
	}

	@RequestMapping(value = "/bookDetails", method = RequestMethod.POST)
	public String registerBookDetails(Model model, @Valid @ModelAttribute("book") BookDetails bookDetails,
			BindingResult result) {

		String view = "";

		if (result.hasErrors()) {
			view = "bookDetails";
		} else {

			int id = service.addBookDetails(bookDetails);

			if (id > 0) {
				view = "success";
				model.addAttribute("id", id);
			} else {
				view = "error";
				model.addAttribute("error", "some problem occured");
			}
		}
		return view;
	}

	@RequestMapping("/selectAll")
	public String getAllBooks(Model model) {

		String view = "";

		List<BookDetails> bookDetails = service.getAllBooks();

		if (bookDetails.size() > 0) {
			view = "showBookDetails";
			model.addAttribute("books", bookDetails);
		}

		return view;
	}

	@RequestMapping("/getBook")
	public String getBookDetails(Model model) {

		String view = "showIdPage";
		model.addAttribute("bookdetails", new BookDetails());
		return view;
	}

	@RequestMapping(value = "/getBookById", method = RequestMethod.POST)
	public String getBookDetailsById(Model model, @ModelAttribute("bookdetails") BookDetails details) {

		String view = "";

		try {
			BookDetails bookDetails = service.getBookById(details.getId());
			model.addAttribute("bookInfo", bookDetails);
			view = "printBookInfo";
		} catch (Exception e) {
			view = "errorMessage";
			model.addAttribute("errorInfo", e.getMessage());
		}

		return view;
	}

}
