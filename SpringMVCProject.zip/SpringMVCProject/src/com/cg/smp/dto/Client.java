package com.cg.smp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "ScheduledSessions")
public class Client {

	
	//declaring the attributes similar to the ScheduledSessions Table in database
	@Id
	@Column
	private Integer id;
	
	@Column
	private String name;
	
	@Column
	private Integer duration;
	
	@Column
	private String faculty;
	
	@Column
	private String mode1;

	public Client() {
		super();
	}

	//---------------------------- Session Schedule Management System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	Client()
	 - Input Parameters	:	Integer id, String name, Integer duration, String faculty, String mode1
	 - Return Type		:	-
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/01/2018
	 - Description		:	Constructor with fields to initialize when every time the objects is created
	 ********************************************************************************************************/
	
	
	public Client(Integer id, String name, Integer duration, String faculty, String mode1) {
		super();
		this.id = id;
		this.name = name;
		this.duration = duration;
		this.faculty = faculty;
		this.mode1 = mode1;
	}


	//---------------------------- Session Schedule Management System --------------------------
	
	//Getters and Setters of all the attributes defined in this class

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	public String getMode1() {
		return mode1;
	}

	public void setMode1(String mode1) {
		this.mode1 = mode1;
	}

	
}
