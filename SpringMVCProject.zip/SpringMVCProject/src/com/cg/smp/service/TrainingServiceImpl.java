package com.cg.smp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.smp.dao.ITrainingDAO;
import com.cg.smp.dto.Client;

@Service("trainingservice")
@Transactional
public class TrainingServiceImpl implements ITrainingService {

	//injection of DAO object
	
	@Autowired
	ITrainingDAO trainingdao;
	
	//---------------------------- Session Schedule Management System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getClientList()
	 - Input Parameters	:	-
	 - Return Type		:	List
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/01/2018
	 - Description		:	Calls the DAO method to retrieve the list from the database
	 ********************************************************************************************************/
	
	@Override
	public List<Client> getClientList() {
		return trainingdao.getClientList() ;
	}

}
