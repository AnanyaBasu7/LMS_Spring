package com.cg.smp.service;

import java.util.List;

import com.cg.smp.dto.Client;

public interface ITrainingService {

	public List<Client> getClientList();
	
}
