package com.cg.smp.dao;

import java.util.List;

import com.cg.smp.dto.Client;

public interface ITrainingDAO {

	
	public List<Client> getClientList();
	
}
