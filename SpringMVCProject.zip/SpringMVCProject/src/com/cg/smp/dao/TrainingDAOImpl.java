package com.cg.smp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.smp.dto.Client;


@Repository("trainingdao")
public class TrainingDAOImpl implements ITrainingDAO{
	
		
	@PersistenceContext
	EntityManager em;
	
	
	//---------------------------- Session Schedule Management System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getClientList()
	 - Input Parameters	:	-
	 - Return Type		:	List
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/01/2018
	 - Description		:	Fetches the data from the database and returns the result in List
	 ********************************************************************************************************/
	
	@Override
	public List<Client> getClientList() {
		Query queryGet=em.createQuery("FROM Client");
		List<Client> myList=queryGet.getResultList();
		return myList;
	}

}
