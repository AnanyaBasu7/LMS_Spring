package com.cg.smp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.smp.dto.Client;
import com.cg.smp.service.ITrainingService;


@Controller
public class TrainingController {

	//Injection of Service object
	
	@Autowired
	ITrainingService trainingservice;

	//---------------------------- Session Schedule Management System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	showDetails()
		 - Input Parameters	:	-
		 - Return Type		:	ModelAndView
		 - Author			:	CAPGEMINI
		 - Creation Date	:	11/01/2018
		 - Description		:	retrieving the list from DAO(repository) with help of Service Object and sends data
		 						to the new JSP File- ScheduledSessions.jsp
		 ********************************************************************************************************/
	
	@RequestMapping(value="/show", method = RequestMethod.GET)
	public ModelAndView showDetails(){
		List<Client> data = trainingservice.getClientList();
		return new ModelAndView("ScheduledSessions", "clientData", data);
	}
	
	
	//---------------------------- Session Schedule Management System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	showSuccess()
			 - Input Parameters	:	@RequestParam("name") String ename
			 - Return Type		:	ModelAndView
			 - Author			:	CAPGEMINI
			 - Creation Date	:	11/01/2018
			 - Description		:	This redirects to the Succes.jsp Page along with the name and prints messgae
			 ********************************************************************************************************/
	
	
	@RequestMapping(value="/success", method = RequestMethod.GET)
	public ModelAndView showSuccess(@RequestParam("name") String ename){
		return new ModelAndView("Success", "name",ename);
	}
	
}
